﻿namespace Agendamento.Models
{
    public class AgendamentosModel
    {
        public int Id { get; set; }
        public string WO { get; set; }
        public string MatriculaTecnico { get; set; }
        public string NomeTecnico { get; set; }
        public string Segmento { get; set; }
        public string UnidadeVinculacao { get; set; }
        public DateTime DataUltimaAtualizacao { get; set; }
        public string MotivoAgendamento { get; set; }
        public string MatriculaResponsavel { get; set; }
        public string NomeResponsavel { get; set; } 


        
    }
}
